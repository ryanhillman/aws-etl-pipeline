import boto3
import pandas as pd
import io

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    obj = s3.get_object(Bucket=bucket, Key=key)
    df = pd.read_csv(io.BytesIO(obj['Body'].read()))
    
    # Example transform: drop missing values and normalize headers
    df = df.dropna()
    df.columns = [c.strip().lower().replace(' ', '_') for c in df.columns]
    
    out_buffer = io.StringIO()
    df.to_csv(out_buffer, index=False)
    
    s3.put_object(
        Bucket='cleaned-data-ryan',  # will exist soon
        Key=f"cleaned/{key}",
        Body=out_buffer.getvalue()
    )
    
    return {"statusCode": 200, "body": f"Processed {key}"}
